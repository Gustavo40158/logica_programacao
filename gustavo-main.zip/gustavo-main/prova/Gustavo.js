
//Variáveis

let nome = "gustavo" 
let idade = 17

console.log("Meu nome é " +   nome)
console.log("tenho " + idade + " anos")






//Condicionais

let nota = 9

if (nota >= 7){
   console.log("aprovado")
}
 
 if (nota >= 5 && nota < 7) {
   console.log("recuperação")
 }
   if (nota < 5 )
   console.log("reprovado")
 
    
 

 //loop for
 
 for (let i= 1 ; i <= 21; i += 2) {
    console.log(i);
 }




 //Arrays

 let frutas = ['maçã', 'morango', 'pera', 'banana', 'uva'];
    console.log('Fruta 1:',frutas[0]);
    console.log('Frutas 2:',frutas[1]);
    console.log('Frutas 3:',frutas[2]);
    console.log('Frutas 4:',frutas[3]);
    console.log('Frutas 5:',frutas[4]);